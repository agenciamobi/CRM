<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Deal, Stage};

class DealController extends Controller
{
    public function index(Request $request)
    {
        return Deal::query()->with(['stage:id,name','contact:id,name'])->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:180',
            'value' => 'nullable|numeric',
            'pipeline_id' => 'required|integer|exists:pipelines,id',
            'stage_id' => 'required|integer|exists:stages,id',
            'contact_id' => 'nullable|integer|exists:contacts,id',
        ]);

        $deal = Deal::create($data);
        return response()->json($deal, 201);
    }

    public function show(Deal $deal) { return $deal->load(['stage','contact']); }

    public function update(Request $request, Deal $deal)
    {
        $deal->update($request->all());
        return $deal->load(['stage','contact']);
    }
}
