<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\{Pipeline, Stage, Deal, Lead};

class DemoSeeder extends Seeder
{
    public function run(): void
    {
        $pipeline = Pipeline::firstOrCreate(['name' => 'Vendas Brasil']);
        $stages = [
            ['name' => 'Contato Inicial', 'order' => 1, 'sla_minutes' => 60],
            ['name' => 'Interessados', 'order' => 2, 'sla_minutes' => 240],
            ['name' => 'Negociação', 'order' => 3, 'sla_minutes' => 720],
            ['name' => 'Fechamento', 'order' => 4, 'sla_minutes' => 1440],
        ];

        foreach ($stages as $s) {
            $pipeline->stages()->firstOrCreate(['name' => $s['name']], $s);
        }

        $stage = $pipeline->stages()->orderBy('order')->first();
        for ($i=1; $i<=10; $i++) {
            Deal::firstOrCreate([
                'title' => "Projeto #$i",
                'pipeline_id' => $pipeline->id,
                'stage_id' => $stage->id,
            ], [
                'value' => rand(1000, 9000),
            ]);
        }

        for ($i=1; $i<=5; $i++) {
            Lead::create([
                'name' => "Lead Exemplo $i",
                'email' => "lead{$i}@example.test",
                'utm_source' => 'demo',
                'utm_campaign' => 'seed',
                'score' => rand(10, 90),
            ]);
        }
    }
}
