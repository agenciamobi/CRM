<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ConfigController extends Controller
{
    public function show(Request $request)
    {
        // Em produção, ler configs por tenant; aqui retornamos stub
        return [
            'features' => config('fcrm.features'),
            'limits' => config('fcrm.limits'),
            'openai' => [
                'model' => config('fcrm.openai.model'),
                'timeout' => config('fcrm.openai.timeout'),
                'has_key' => (bool) config('fcrm.openai.api_key'),
            ],
        ];
    }

    public function update(Request $request)
    {
        // Stub: persistir configs no DB por tenant
        return response()->json(['ok' => true]);
    }
}
