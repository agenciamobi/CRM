<?php

return [
    'features' => [
        'ai_agent' => true,
        'webhooks' => true,
        'automations' => true,
        'portal_cliente' => false,
    ],

    'limits' => [
        'ai_calls_per_month' => 2000,
        'users' => 50,
        'pipelines' => 5,
    ],

    'openai' => [
        'model' => env('OPENAI_MODEL', 'gpt-4.1-mini'),
        'timeout' => env('OPENAI_TIMEOUT', 20),
        // api key por tenant ficará criptografada no DB; esta é fallback global
        'api_key' => env('OPENAI_API_KEY'),
    ],
];
