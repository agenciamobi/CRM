<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Lead, Deal};
use App\Services\OpenAIService;

class AIController extends Controller
{
    public function triageLead(Request $request, Lead $lead, OpenAIService $ai)
    {
        $result = $ai->triageLead($lead);
        return response()->json($result);
    }

    public function suggestReplies(Request $request, Deal $deal, OpenAIService $ai)
    {
        $result = $ai->suggestReplies($deal);
        return response()->json($result);
    }
}
