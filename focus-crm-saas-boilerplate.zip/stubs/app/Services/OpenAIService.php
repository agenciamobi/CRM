<?php

namespace App\Services;

use App\Models\{Lead, Deal};

class OpenAIService
{
    public function triageLead(Lead $lead): array
    {
        // Aqui você chamaria a API da OpenAI (SDK ou HTTP). Mantemos stub para rodar sem chave.
        $summary = sprintf('Lead %s triado: possível interesse em %s', $lead->name, $lead->utm_campaign ?? 'produto/serviço');
        return [
            'summary' => $summary,
            'score' => 72,
            'next_action' => 'Ligar em até 2h',
        ];
    }

    public function suggestReplies(Deal $deal): array
    {
        return [
            'replies' => [
                'Olá {{nome}}, vi seu interesse. Posso te ligar hoje para alinhar detalhes?',
                'Obrigado pelo retorno! Segue uma proposta resumida; se fizer sentido, agendamos uma call.',
                'Conseguiu avaliar, {{nome}}? Posso ajustar valores/prazos para encaixar melhor.',
            ],
        ];
    }
}
