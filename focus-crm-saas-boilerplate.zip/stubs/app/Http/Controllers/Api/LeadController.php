<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Lead, Contact};

class LeadController extends Controller
{
    public function index(Request $request)
    {
        $q = Lead::query();

        if ($s = $request->string('search')->toString()) {
            $q->where(function($w) use ($s) {
                $w->where('name','like',"%$s%")->orWhere('email','like',"%$s%")->orWhere('phone','like',"%$s%");
            });
        }
        return $q->orderByDesc('id')->paginate(50);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:120',
            'email' => 'nullable|email|max:160',
            'phone' => 'nullable|string|max:40',
            'message' => 'nullable|string',
            'utm_source' => 'nullable|string|max:160',
            'utm_medium' => 'nullable|string|max:160',
            'utm_campaign' => 'nullable|string|max:160',
        ]);

        $lead = Lead::create($data);
        return response()->json($lead, 201);
    }

    public function show(Lead $lead)
    {
        return $lead;
    }

    public function update(Request $request, Lead $lead)
    {
        $lead->update($request->all());
        return $lead;
    }
}
