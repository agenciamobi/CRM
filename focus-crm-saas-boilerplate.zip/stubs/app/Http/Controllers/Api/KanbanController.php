<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Pipeline, Stage, Deal};

class KanbanController extends Controller
{
    public function pipelines()
    {
        return Pipeline::query()->select('id','name')->orderBy('name')->get();
    }

    public function stages(Pipeline $pipeline)
    {
        return $pipeline->stages()->select('id','name','order','sla_minutes')->orderBy('order')->get();
    }

    public function cards(Pipeline $pipeline)
    {
        $deals = Deal::query()
            ->where('pipeline_id', $pipeline->id)
            ->with(['contact:id,name,email,phone','stage:id,name,order'])
            ->orderBy('updated_at','desc')
            ->limit(500)
            ->get();

        return $deals;
    }

    public function move(Request $request, Deal $deal)
    {
        $request->validate([
            'stage_id' => ['required','integer','exists:stages,id'],
        ]);

        $deal->update(['stage_id' => $request->integer('stage_id')]);
        return response()->json(['ok' => true]);
    }
}
