<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\{KanbanController, LeadController, DealController, WebhookController, AIController, ConfigController};

Route::middleware(['auth:sanctum'])->group(function () {
    Route::get('/kanban/pipelines', [KanbanController::class, 'pipelines']);
    Route::get('/kanban/{pipeline}/stages', [KanbanController::class, 'stages']);
    Route::get('/kanban/{pipeline}/cards', [KanbanController::class, 'cards']);
    Route::post('/kanban/card/{deal}/move', [KanbanController::class, 'move']);

    Route::apiResource('leads', LeadController::class)->only(['index','store','show','update']);
    Route::apiResource('deals', DealController::class)->only(['index','store','show','update']);

    Route::post('/ai/triage-lead/{lead}', [AIController::class, 'triageLead']);
    Route::post('/ai/suggest-replies/{deal}', [AIController::class, 'suggestReplies']);

    Route::get('/config', [ConfigController::class, 'show']);
    Route::put('/config', [ConfigController::class, 'update']);
});

// Webhooks (assinatura via HMAC + idempotência)
Route::post('/webhooks/forms', [WebhookController::class, 'forms']);
Route::post('/webhooks/whatsapp-click', [WebhookController::class, 'whatsappClick']);
Route::post('/webhooks/social', [WebhookController::class, 'social']);
