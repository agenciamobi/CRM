<template>
  <div class="p-4">
    <h1 class="text-2xl font-bold mb-4">Kanban — {{ pipeline?.name || 'Carregando' }}</h1>
    <div class="grid grid-cols-4 gap-4">
      <div v-for="s in stages" :key="s.id" class="bg-gray-50 rounded-xl p-3 shadow">
        <div class="font-semibold mb-2 flex items-center justify-between">
          <span>{{ s.name }}</span>
          <span class="text-sm opacity-60">{{ cardsByStage(s.id).length }}</span>
        </div>
        <div class="space-y-2">
          <div v-for="c in cardsByStage(s.id)" :key="c.id" class="bg-white rounded-lg p-3 shadow border">
            <div class="font-medium">{{ c.title }}</div>
            <div class="text-sm opacity-70">R$ {{ c.value || 0 }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'

const pipeline = ref<any>(null)
const stages = ref<any[]>([])
const cards = ref<any[]>([])

async function fetchAll() {
  const resP = await fetch('/api/kanban/pipelines', { credentials: 'include' })
  const pipelines = await resP.json()
  pipeline.value = pipelines[0]

  const resS = await fetch(`/api/kanban/${pipeline.value.id}/stages`, { credentials: 'include' })
  stages.value = await resS.json()

  const resC = await fetch(`/api/kanban/${pipeline.value.id}/cards`, { credentials: 'include' })
  cards.value = await resC.json()
}

function cardsByStage(stageId:number) {
  return cards.value.filter((c:any) => c.stage_id === stageId)
}

onMounted(fetchAll)
</script>
