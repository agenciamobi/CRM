#!/usr/bin/env bash
set -euo pipefail

if [ ! -f artisan ]; then
  echo ">> Criando projeto Laravel 11..."
  composer create-project laravel/laravel . --prefer-dist
fi

echo ">> Instalando pacotes..."
composer require laravel/horizon laravel/sanctum predis/predis guzzlehttp/guzzle openai-php/client fruitcake/laravel-cors --with-all-dependencies

# Dev tools
composer require --dev pestphp/pest pestphp/pest-plugin-laravel laravel/pint phpstan/phpstan nunomaduro/larastan --with-all-dependencies

echo ">> Publicando Horizon e Sanctum..."
php artisan vendor:publish --provider="Laravel\Horizon\HorizonServiceProvider"
php artisan vendor:publish --provider="Fruitcake\Cors\CorsServiceProvider" || true

echo ">> Copiando stubs do boilerplate..."
rsync -a --ignore-existing stubs/app/ app/
rsync -a --ignore-existing stubs/config/ config/
rsync -a --ignore-existing stubs/database/ database/
rsync -a --ignore-existing stubs/routes/ routes/
rsync -a --ignore-existing stubs/resources/ resources/

if ! grep -q "QUEUE_CONNECTION=redis" .env 2>/dev/null; then
  cp .env.example .env
fi

echo ">> Gerando APP_KEY..."
php artisan key:generate

echo ">> Link de storage (se aplicável)..."
php artisan storage:link || true

echo ">> Finalizado! Agora rode: make migrate && make seed"
