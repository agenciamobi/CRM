<?php

namespace App\Services;

use App\Models\{Lead, Deal};

class AutomationEngine
{
    public function handleLeadCreated(Lead $lead): void
    {
        // exemplo: atribuição automática / criar tarefa / notificar
    }

    public function handleDealMoved(Deal $deal): void
    {
        // exemplo: SLA, notificação, etc.
    }
}
