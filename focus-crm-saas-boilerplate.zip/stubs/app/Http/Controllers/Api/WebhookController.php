<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\Models\{WebhookEvent, Lead};

class WebhookController extends Controller
{
    protected function verifySignature(Request $request): void
    {
        // Exemplo simples: X-Signature: HMAC SHA256 do body usando secret do tenant (stub: .env)
        $secret = config('app.key');
        $signature = $request->header('X-Signature', '');
        $calc = hash_hmac('sha256', $request->getContent(), $secret);
        abort_unless(hash_equals($calc, $signature), 401, 'Invalid signature');
    }

    public function forms(Request $request)
    {
        $this->verifySignature($request);

        $payload = $request->all();
        $eventId = (string)($payload['event_id'] ?? Str::uuid());

        // idempotência
        $exists = WebhookEvent::query()->where('external_event_id', $eventId)->exists();
        if ($exists) {
            return response()->json(['ok' => true, 'duplicate' => true], 202);
        }

        DB::transaction(function () use ($payload, $eventId) {
            WebhookEvent::create([
                'type' => 'form',
                'external_event_id' => $eventId,
                'payload' => $payload,
            ]);

            Lead::create([
                'name' => $payload['name'] ?? 'Sem nome',
                'email' => $payload['email'] ?? null,
                'phone' => $payload['phone'] ?? null,
                'message' => $payload['message'] ?? null,
                'utm_source' => $payload['utm_source'] ?? null,
                'utm_medium' => $payload['utm_medium'] ?? null,
                'utm_campaign' => $payload['utm_campaign'] ?? null,
            ]);
        });

        return response()->json(['ok' => true], 202);
    }

    public function whatsappClick(Request $request)
    {
        $this->verifySignature($request);

        WebhookEvent::create([
            'type' => 'whatsapp_click',
            'external_event_id' => (string) Str::uuid(),
            'payload' => $request->all(),
        ]);

        return response()->json(['ok' => true], 202);
    }

    public function social(Request $request)
    {
        $this->verifySignature($request);

        WebhookEvent::create([
            'type' => 'social',
            'external_event_id' => (string) Str::uuid(),
            'payload' => $request->all(),
        ]);

        return response()->json(['ok' => true], 202);
    }
}
